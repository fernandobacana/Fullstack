require("colors");

var http = require("http");
var express = require("express");
var bodyParser = require("body-parser")

const { createClient } = require('@supabase/supabase-js')

const supabase = createClient(
  'https://ckzcimkycqflwuzyuqjw.supabase.co',
  'sb_publishable_k6W6g6txdpRa4Lp8V2wFKA_xmNdqckB'
)

var app = express();

app.use(express.static("./public"));
app.use(bodyParser.urlencoded({extended: false }))
app.use(bodyParser.json())

app.set('view engine', 'ejs')
app.set('views', './views');

var server = http.createServer(app);

server.listen(80);

console.log("Servidor rodando ...".rainbow);

////////////////////////////////////////////// 

app.get('/', function(requisicao, resposta){
    resposta.redirect('contato.html');
})

app.get('/cadastrar',function(requisicao, resposta){

    console.log('Requisição recebida por get');

    let nome = requisicao.query.nome;
    let email = requisicao.query.email;
    let telefone = requisicao.query.telefone;
    let nascimento = requisicao.query.nascimento;

    console.log(nome, email, telefone, nascimento)

    resposta.render('resposta.ejs', {
        metodo:"GET",
        nome,
        email,
        telefone,
        nascimento
    });

})

app.post('/cadastrar',function(requisicao, resposta){

    console.log('Requisição recebida por post');

    let nome = requisicao.body.nome;
    let email = requisicao.body.email;
    let telefone = requisicao.body.telefone;
    let nascimento = requisicao.body.nascimento;

    console.log(nome, email, telefone, nascimento)

    resposta.render('resposta.ejs', {
        metodo:"POST",
        nome,
        email,
        telefone,
        nascimento
    });

})

app.get('/for', function(requisicao, resposta){

    let qtde = requisicao.query.qtde;

    console.log(qtde);

    resposta.render('for.ejs', {qtde})

})

////////////////////////////////////////////// 

var usuarios = "usuarios";

app.post("/cadastrar_usuario", async function(req, resp) {

    var data = {
        db_nome: req.body.nome,
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    const { error } = await supabase
        .from(usuarios)
        .insert([data])

    if (error) {

        console.log(error)

        resp.render('resposta_usuario', {
            resposta: "Erro ao cadastrar usuário!"
        })

    } else {

        resp.render('resposta_usuario', {
            resposta: "Usuário cadastrado com sucesso!"
        })

    }

});

app.post("/logar_usuario", async function(req, resp) {

    const { data, error } = await supabase
        .from(usuarios)
        .select('*')
        .eq('db_login', req.body.login)
        .eq('db_senha', req.body.senha)

    if (error) {

        console.log(error)

        resp.render('resposta_usuario', {
            resposta: "Erro ao logar usuário!"
        })

    } else if (data.length == 0) {

        resp.render('resposta_usuario', {
            resposta: "Usuário/senha não encontrado!"
        })

    } else {

        resp.render('resposta_usuario', {
            resposta: "Usuário logado com sucesso!"
        })

    }

});

app.post("/atualizar_usuario", async function(req, resp) {

    const { error } = await supabase
        .from(usuarios)
        .update({
            db_senha: req.body.novasenha
        })
        .eq('db_login', req.body.login)
        .eq('db_senha', req.body.senha)

    if (error) {

        console.log(error)

        resp.render('resposta_usuario', {
            resposta: "Erro ao atualizar usuário!"
        })

    } else {

        resp.render('resposta_usuario', {
            resposta: "Usuário atualizado com sucesso!"
        })

    }

});

app.post("/remover_usuario", async function(req, resp) {

    const { error } = await supabase
        .from(usuarios)
        .delete()
        .eq('db_login', req.body.login)
        .eq('db_senha', req.body.senha)

    if (error) {

        console.log(error)

        resp.render('resposta_usuario', {
            resposta: "Erro ao remover usuário!"
        })

    } else {

        resp.render('resposta_usuario', {
            resposta: "Usuário removido com sucesso!"
        })

    }

});